scriptGetVideo - is defined by the loaded script aka WatchRPC_YTMusic and grabs the video data from the loaded page

clientGetVideo - is defined by global utils and sends the saved video data to the desktop app

